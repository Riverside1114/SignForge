import os, sys, json, hashlib, base64, struct, secrets, time
from pathlib import Path
from datetime import datetime

try:
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:
    print("Run: pip install cryptography")
    sys.exit(1)

VERSION   = "1.0.0"
SIGN_EXT  = ".sig"
CERT_EXT  = ".crt"
E = chr(27)
R=E+"[91m"; G=E+"[92m"; Y=E+"[93m"; B=E+"[94m"
C=E+"[96m"; W=E+"[97m"; DIM=E+"[2m"; BOLD=E+"[1m"; RST=E+"[0m"
os.system("")


def ts():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def banner():
    print(C+BOLD+"""
+====================================================+
|   SignForge  v1.0  --  Code Signing System         |
|   RSA-4096 signatures  |  SHA3-512 file hashes     |
|   Tamper detection  |  Identity certificates       |
+====================================================+
"""+RST)

def ok(m):   print("  "+G+"  "+m+RST)
def err(m):  print("  "+R+"  "+m+RST)
def info(m): print("  "+C+"  "+m+RST)
def warn(m): print("  "+Y+"  "+m+RST)
def sep():   print("  "+DIM+"-"*50+RST)

def kdf(pw, salt, iters=200_000):
    s = hashlib.sha3_512(pw.encode() + salt).digest()
    for i in range(iters):
        ctr = i.to_bytes(4, "big")
        if i % 2 == 0: s = hashlib.sha3_512(s + salt + ctr).digest()
        else:           s = hashlib.blake2b(s + pw.encode() + ctr, digest_size=64).digest()
    return hashlib.sha3_256(s + b"SignForge-v1" + salt).digest()

def aes_enc(data, key):
    n = secrets.token_bytes(12)
    return n + AESGCM(key).encrypt(n, data, b"SignForge-v1")

def aes_dec(data, key):
    return AESGCM(key).decrypt(data[:12], data[12:], b"SignForge-v1")


def hash_file(path: Path) -> str:
    h = hashlib.sha3_512()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk: break
            h.update(chunk)
    return h.hexdigest()

def fingerprint(pub_pem: bytes) -> str:
    d = hashlib.sha3_256(pub_pem).hexdigest()
    return ":".join(d[i:i+4] for i in range(0, 32, 4))

def gen_keypair():
    priv = rsa.generate_private_key(65537, 4096, default_backend())
    return priv, priv.public_key()

def export_pub(pub) -> bytes:
    return pub.public_bytes(serialization.Encoding.PEM,
                            serialization.PublicFormat.SubjectPublicKeyInfo)

def export_priv_raw(priv) -> bytes:
    return priv.private_bytes(serialization.Encoding.PEM,
                              serialization.PrivateFormat.TraditionalOpenSSL,
                              serialization.NoEncryption())

def load_pub(pem: bytes):
    return serialization.load_pem_public_key(pem, backend=default_backend())

def load_priv(pem: bytes):
    return serialization.load_pem_private_key(pem, password=None, backend=default_backend())

def rsa_sign(priv, data: bytes) -> bytes:
    return priv.sign(data, padding.PSS(
        mgf=padding.MGF1(hashes.SHA512()),
        salt_length=padding.PSS.MAX_LENGTH), hashes.SHA512())

def rsa_verify(pub, sig: bytes, data: bytes) -> bool:
    try:
        pub.verify(sig, data, padding.PSS(
            mgf=padding.MGF1(hashes.SHA512()),
            salt_length=padding.PSS.MAX_LENGTH), hashes.SHA512())
        return True
    except:
        return False


SEPARATOR = b"---SIGNFORGE---\n"

def write_key_file(path: Path, meta: dict, key_data: bytes):
    header = json.dumps(meta, indent=2).encode() + b"\n"
    path.write_bytes(header + SEPARATOR + key_data)

def read_key_file(path: Path) -> tuple:
    raw     = path.read_bytes()
    sep_idx = raw.find(SEPARATOR)
    if sep_idx == -1:
        raise ValueError("Not a valid SignForge key file: "+path.name)
    meta     = json.loads(raw[:sep_idx].decode())
    key_data = raw[sep_idx + len(SEPARATOR):]
    return meta, key_data

def cmd_generate(args):
    import getpass
    sep()
    print("  "+B+BOLD+"Generate Signing Identity"+RST)
    sep()

    name  = input("  Your name / tool author name: ").strip()
    email = input("  Email or contact (optional)  : ").strip()
    tools = input("  Tools this identity covers    : ").strip()

    if not name:
        err("Name cannot be empty."); return

    out_dir = Path(input("  Save keys to folder [.]: ").strip() or ".")
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_name = name.lower().replace(" ","_")

    import getpass as gp
    pw  = gp.getpass("  Passphrase to protect private key : ")
    pw2 = gp.getpass("  Confirm passphrase                : ")
    if pw != pw2:
        err("Passphrases do not match."); return

    print()
    info("Generating RSA-4096 signing keypair...")
    priv, pub = gen_keypair()
    pub_pem   = export_pub(pub)
    priv_pem  = export_priv_raw(priv)
    fp        = fingerprint(pub_pem)

    info("Encrypting private key...")
    salt    = secrets.token_bytes(32)
    key     = kdf(pw, salt)
    enc_priv = aes_enc(priv_pem, key)

    meta_pub = {
        "signforge_version": VERSION,
        "type":        "SignForge Public Key",
        "name":        name,
        "email":       email,
        "tools":       tools,
        "created":     ts(),
        "fingerprint": fp,
    }
    meta_priv = {
        "signforge_version": VERSION,
        "type":        "SignForge Private Key (AES-256 locked)",
        "name":        name,
        "email":       email,
        "tools":       tools,
        "created":     ts(),
        "fingerprint": fp,
    }
    meta_priv_data = {"salt": base64.b64encode(salt).decode()}

    pub_path  = out_dir / (safe_name + ".sfpub")
    priv_path = out_dir / (safe_name + ".sfpriv")

    write_key_file(pub_path,  meta_pub,  pub_pem)
    write_key_file(priv_path, meta_priv, base64.b64encode(salt).decode().encode() + b"|" + enc_priv)

    print()
    ok("Public key  -> "+str(pub_path))
    ok("Private key -> "+str(priv_path)+"  (passphrase locked)")
    print()
    sep()
    print("  "+C+"Identity Certificate"+RST)
    print("  Name        : "+BOLD+name+RST)
    if email: print("  Email       : "+email)
    if tools: print("  Tools       : "+tools)
    print("  Created     : "+ts())
    print("  Fingerprint : "+Y+fp+RST)
    sep()
    print()
    warn("Share your .sfpub file with anyone who wants to verify your tools.")
    warn("Keep your .sfpriv file secret and backed up safely.")
    warn("If you lose your .sfpriv -- you cannot sign anything. No recovery.")


def _load_priv_key(priv_path: Path, pw: str):
    meta, raw = read_key_file(priv_path)
    sep_idx   = raw.find(b"|")
    salt      = base64.b64decode(raw[:sep_idx])
    enc_priv  = raw[sep_idx+1:]
    key       = kdf(pw, salt)
    try:
        priv_pem = aes_dec(enc_priv, key)
    except:
        raise ValueError("Wrong passphrase or corrupted key file.")
    return load_priv(priv_pem), meta

def cmd_sign(args):
    import getpass as gp
    sep()
    print("  "+B+BOLD+"Sign a File or Folder"+RST)
    sep()

    target_str = (args[0] if args else input("  File or folder to sign: ").strip())
    target     = Path(target_str)
    if not target.exists():
        target = Path.cwd() / target_str
    if not target.exists():
        err("Not found: "+target_str); return

    priv_str = (args[1] if len(args)>1 else input("  Path to .sfpriv key: ").strip())
    priv_path = Path(priv_str)
    if not priv_path.exists():
        err("Key not found: "+priv_str); return

    pw = gp.getpass("  Passphrase: ")

    print()
    info("Loading private key...")
    try:
        priv, key_meta = _load_priv_key(priv_path, pw)
    except ValueError as ex:
        err(str(ex)); return

    info("Hashing target...")
    if target.is_file():
        file_hash = hash_file(target)
        files_manifest = {target.name: file_hash}
    else:
        files_manifest = {}
        for f in sorted(target.rglob("*")):
            if f.is_file():
                rel = str(f.relative_to(target))
                files_manifest[rel] = hash_file(f)
        file_hash = hashlib.sha3_512(
            json.dumps(files_manifest, sort_keys=True).encode()).hexdigest()

    info("Signing with RSA-4096 + SHA3-512...")
    sign_payload = json.dumps({
        "target":    target.name,
        "hash":      file_hash,
        "files":     files_manifest,
        "algorithm": "RSA-4096-PSS-SHA3-512",
        "signed_by": key_meta.get("name","?"),
        "signed_at": ts(),
        "version":   VERSION,
    }, sort_keys=True).encode()

    sig = rsa_sign(priv, sign_payload)

    sig_data = {
        "signforge_version": VERSION,
        "target":      target.name,
        "hash":        file_hash,
        "files":       files_manifest,
        "algorithm":   "RSA-4096-PSS-SHA3-512",
        "signed_by":   key_meta.get("name","?"),
        "email":       key_meta.get("email",""),
        "fingerprint": key_meta.get("fingerprint",""),
        "signed_at":   ts(),
        "signature":   base64.b64encode(sig).decode(),
        "payload":     base64.b64encode(sign_payload).decode(),
    }

    sig_path = Path(str(target) + SIGN_EXT)
    sig_path.write_text(json.dumps(sig_data, indent=2))

    print()
    ok("Signed!  Signature file -> "+str(sig_path))
    ok("SHA3-512 hash : "+Y+file_hash[:32]+"..."+RST)
    ok("Signed by     : "+BOLD+key_meta.get("name","?")+RST)
    ok("Fingerprint   : "+Y+key_meta.get("fingerprint","?")+RST)
    print()
    info("Distribute the .sig file alongside your tool.")
    info("Users verify with: signforge verify <file> <file.sig> <you.sfpub>")


def cmd_verify(args):
    sep()
    print("  "+B+BOLD+"Verify a Signature"+RST)
    sep()

    target_str = (args[0] if args else input("  File or folder to verify: ").strip())
    target     = Path(target_str)
    if not target.exists(): target = Path.cwd() / target_str
    if not target.exists():
        err("Not found: "+target_str); return

    sig_str = (args[1] if len(args)>1 else input("  Path to .sig file: ").strip())
    sig_path = Path(sig_str)
    if not sig_path.exists():
        auto = Path(str(target)+SIGN_EXT)
        if auto.exists():
            sig_path = auto
            info("Auto-detected signature: "+str(sig_path))
        else:
            err("Signature not found: "+sig_str); return

    pub_str  = (args[2] if len(args)>2 else input("  Path to .sfpub key : ").strip())
    pub_path = Path(pub_str)
    if not pub_path.exists():
        sf_pubs = list(Path.cwd().glob("*.sfpub"))
        if len(sf_pubs) == 1:
            pub_path = sf_pubs[0]
            info("Auto-detected public key: "+str(pub_path))
        else:
            err("Public key not found: "+pub_str); return

    print()
    info("Loading public key...")
    try:
        key_meta, pub_pem = read_key_file(pub_path)
        pub = load_pub(pub_pem)
    except Exception as ex:
        err("Failed to load public key: "+str(ex)); return

    info("Loading signature file...")
    try:
        sig_data = json.loads(sig_path.read_text())
    except Exception as ex:
        err("Failed to read signature: "+str(ex)); return

    info("Hashing target...")
    if target.is_file():
        actual_hash   = hash_file(target)
        files_actual  = {target.name: actual_hash}
    else:
        files_actual  = {}
        for f in sorted(target.rglob("*")):
            if f.is_file():
                rel = str(f.relative_to(target))
                files_actual[rel] = hash_file(f)
        actual_hash = hashlib.sha3_512(
            json.dumps(files_actual, sort_keys=True).encode()).hexdigest()

    print()
    sep()
    print("  "+C+"Verification Report"+RST)
    sep()

    expected_hash = sig_data.get("hash","")
    hash_ok = actual_hash == expected_hash
    print("  Hash match  : "+( G+BOLD+"PASS"+RST if hash_ok else R+BOLD+"FAIL"+RST))
    if not hash_ok:
        print("  "+R+"  Expected : "+expected_hash[:32]+"..."+RST)
        print("  "+R+"  Got      : "+actual_hash[:32]+"..."+RST)

    expected_files = sig_data.get("files",{})
    file_check_ok  = True
    if expected_files and target.is_dir():
        for rel, expected_fh in expected_files.items():
            actual_fh = files_actual.get(rel,"")
            if actual_fh != expected_fh:
                print("  "+R+"  MODIFIED : "+rel+RST)
                file_check_ok = False
        new_files = set(files_actual.keys()) - set(expected_files.keys())
        for rel in new_files:
            print("  "+Y+"  NEW FILE : "+rel+RST)
        del_files = set(expected_files.keys()) - set(files_actual.keys())
        for rel in del_files:
            print("  "+R+"  DELETED  : "+rel+RST)
            file_check_ok = False
        if file_check_ok and not new_files:
            print("  Files       : "+G+BOLD+"ALL MATCH"+RST)
        elif new_files:
            print("  New files   : "+Y+str(len(new_files))+" extra file(s) not in signature"+RST)

    payload_b64 = sig_data.get("payload","")
    sig_b64     = sig_data.get("signature","")
    sig_ok      = False
    try:
        payload = base64.b64decode(payload_b64)
        sig     = base64.b64decode(sig_b64)
        sig_ok  = rsa_verify(pub, sig, payload)
    except: pass

    print("  RSA sig     : "+( G+BOLD+"VALID"+RST if sig_ok else R+BOLD+"INVALID"+RST))

    fp_in_sig = sig_data.get("fingerprint","")
    fp_pubkey = fingerprint(pub_pem)
    fp_ok     = fp_in_sig == fp_pubkey
    print("  Fingerprint : "+( G+BOLD+"MATCH"+RST if fp_ok else R+BOLD+"MISMATCH"+RST))
    print("    Sig  key  : "+Y+fp_in_sig+RST)
    print("    Pub  key  : "+Y+fp_pubkey+RST)

    print()
    print("  Signed by   : "+BOLD+sig_data.get("signed_by","?")+RST)
    if sig_data.get("email"): print("  Email       : "+sig_data.get("email",""))
    print("  Signed at   : "+sig_data.get("signed_at","?"))
    sep()

    all_ok = hash_ok and sig_ok and fp_ok and file_check_ok
    if all_ok:
        print("  "+G+BOLD+"RESULT: VERIFIED -- File is authentic and untampered."+RST)
    else:
        print("  "+R+BOLD+"RESULT: FAILED   -- File may be tampered or corrupted!"+RST)
        if not sig_ok:   warn("Signature is invalid -- file was not signed by this key.")
        if not hash_ok:  warn("Hash mismatch -- file contents have changed since signing.")
        if not fp_ok:    warn("Fingerprint mismatch -- wrong public key used for verification.")
    print()


def cmd_fingerprint(args):
    sep()
    key_str  = (args[0] if args else input("  Path to .sfpub or .sfpriv: ").strip())
    key_path = Path(key_str)
    if not key_path.exists():
        key_path = Path.cwd() / key_str
    if not key_path.exists():
        err("Not found: "+key_str); return
    try:
        meta, key_data = read_key_file(key_path)
        if meta.get("type","").startswith("SignForge Public"):
            pub = load_pub(key_data)
            fp  = fingerprint(export_pub(pub))
        else:
            fp  = meta.get("fingerprint","unknown")
        sep()
        print("  "+C+"Key Info"+RST)
        print("  Name        : "+BOLD+meta.get("name","?")+RST)
        if meta.get("email"): print("  Email       : "+meta.get("email",""))
        if meta.get("tools"): print("  Tools       : "+meta.get("tools",""))
        print("  Type        : "+meta.get("type","?"))
        print("  Created     : "+meta.get("created","?"))
        print("  Fingerprint : "+Y+fp+RST)
        sep()
    except Exception as ex:
        err("Failed: "+str(ex))

def cmd_inspect(args):
    sep()
    sig_str  = (args[0] if args else input("  Path to .sig file: ").strip())
    sig_path = Path(sig_str)
    if not sig_path.exists():
        sig_path = Path.cwd() / sig_str
    if not sig_path.exists():
        err("Not found: "+sig_str); return
    try:
        sig_data = json.loads(sig_path.read_text())
        sep()
        print("  "+C+"Signature Info"+RST)
        print("  Target      : "+BOLD+sig_data.get("target","?")+RST)
        print("  Signed by   : "+BOLD+sig_data.get("signed_by","?")+RST)
        if sig_data.get("email"): print("  Email       : "+sig_data.get("email",""))
        print("  Signed at   : "+sig_data.get("signed_at","?"))
        print("  Algorithm   : "+sig_data.get("algorithm","?"))
        print("  Signer FP   : "+Y+sig_data.get("fingerprint","?")+RST)
        print("  Hash        : "+Y+sig_data.get("hash","?")[:32]+"..."+RST)
        files = sig_data.get("files",{})
        if files:
            print("  Files       : "+str(len(files))+" file(s) in manifest")
            for rel in list(files.keys())[:5]:
                print("    "+DIM+rel+RST)
            if len(files) > 5:
                print("    "+DIM+"... and "+str(len(files)-5)+" more"+RST)
        sep()
    except Exception as ex:
        err("Failed: "+str(ex))


def menu():
    while True:
        print()
        print("  "+B+BOLD+"======  SignForge  ======"+RST+"\n")
        print("    "+Y+"1"+RST+".  Generate identity & signing keys")
        print("    "+Y+"2"+RST+".  Sign a file or folder")
        print("    "+Y+"3"+RST+".  Verify a signature")
        print("    "+Y+"4"+RST+".  View key fingerprint")
        print("    "+Y+"5"+RST+".  Inspect a .sig file")
        print("    "+Y+"6"+RST+".  Exit")
        print()
        ch = input("  "+Y+">"+RST+" ").strip()
        if   ch == "1": cmd_generate([])
        elif ch == "2": cmd_sign([])
        elif ch == "3": cmd_verify([])
        elif ch == "4": cmd_fingerprint([])
        elif ch == "5": cmd_inspect([])
        elif ch == "6": print("  "+G+"Goodbye."+RST+"\n"); sys.exit(0)
        else: err("Invalid option.")

def main():
    banner()
    args = sys.argv[1:]
    if not args:
        menu(); return
    cmd  = args[0].lower()
    rest = args[1:]
    if cmd == "generate":  cmd_generate(rest)
    elif cmd == "sign":    cmd_sign(rest)
    elif cmd == "verify":  cmd_verify(rest)
    elif cmd == "fingerprint": cmd_fingerprint(rest)
    elif cmd == "inspect": cmd_inspect(rest)
    else:
        err("Unknown command: "+cmd)
        print("  Commands: generate  sign  verify  fingerprint  inspect")

if __name__ == "__main__":
    main()
